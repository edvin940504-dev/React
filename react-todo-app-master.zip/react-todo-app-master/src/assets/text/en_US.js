export const MSG_NO_ITEMS = 'There are no items.';
export const INFO_SHORTCUT_KEYS = 'Press `/` to search and `N` to create a new item.';
export const INFO_CANCEL_SHORTCUT_KEY = 'Press `Esc` to cancel.';
