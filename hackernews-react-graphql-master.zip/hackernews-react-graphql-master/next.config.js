module.exports = {
  future: {
    webpack5: true,
  },
  webpack: (config) => {
    // Perform customizations to webpack config

    return config;
  },
};
