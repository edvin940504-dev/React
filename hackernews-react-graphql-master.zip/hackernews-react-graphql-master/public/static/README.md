This folder holds all of the static assets for build.
