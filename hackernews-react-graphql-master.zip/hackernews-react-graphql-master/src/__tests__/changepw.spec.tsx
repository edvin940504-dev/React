/** @jest-environment jsdom */

import Page from '../../pages/changepw';

describe('Change Password Page', () => {
  it('has default export', () => {
    expect(Page).toBeDefined();
  });
});
