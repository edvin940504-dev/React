export enum FeedType {
  TOP = 'top',
  NEW = 'new',
  BEST = 'best',
  SHOW = 'show',
  ASK = 'ask',
  JOB = 'job',
}
