### Directory Structure

*docs* - Contains extra documentation.