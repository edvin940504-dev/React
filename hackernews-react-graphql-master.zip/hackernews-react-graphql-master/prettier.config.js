module.exports = {
  singleQuote: true,
  printWidth: 100,
};
